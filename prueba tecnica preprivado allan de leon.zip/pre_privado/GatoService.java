@Service
public class GatoService {
	

    @Autowired
    private GatoRepository gatoRepository;

    public List<Gato> obtenerTodosLosGatos() {
        return gatoRepository.findAll();
    }

    public Gato obtenerGatoPorId(String id) {
        return gatoRepository.findById(id).orElse(null);
    }

    public void crearGato(Gato gato) {
        gatoRepository.save(gato);
    }

    public void actualizarGato(String id, Gato gato) {
        gato.setId(id);
        gatoRepository.save(gato);
    }

    public void eliminarGato(String id) {
        gatoRepository.deleteById(id);
    }
}
