
public class Imagen {
	 private String id;
	    private String url;
}
