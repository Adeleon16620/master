@Service
public class ImagenService {
	private List<Imagen> imagenesFavoritas = new ArrayList<>();

    public List<Imagen> obtenerImagenesAleatorias() {
        return Collections.emptyList();
    }

    public void marcarImagenComoFavorita(String imagenId) {
  }

    public List<Imagen> obtenerImagenesFavoritas() {
       return imagenesFavoritas;
    }
}
