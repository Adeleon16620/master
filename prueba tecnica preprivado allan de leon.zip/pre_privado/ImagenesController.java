
public class ImagenesController {
	
}
	import org.springframework.http.HttpEntity;
	import org.springframework.http.HttpHeaders;
	import org.springframework.http.HttpMethod;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RestController;
	import org.springframework.web.client.RestTemplate;

	import java.util.Arrays;
	import java.util.List;

	@RestController
	public class ImagenesController {

	    private static final String API_URL = "https://api.thecatapi.com/v1/images/search?limit=10";
	    private static final String API_KEY = "f221c99b-304d-4404-b111-cbd3ddccf31a";

	    @GetMapping("/imagenes")
	    public ResponseEntity<List<Imagen>> obtenerImagenesAleatorias() {
	        RestTemplate restTemplate = new RestTemplate();
	        HttpHeaders headers = new HttpHeaders();
	        headers.set("x-api-key", API_KEY);
	        HttpEntity<String> requestEntity = new HttpEntity<>(headers);
   	        ResponseEntity<Imagen[]> responseEntity = restTemplate.exchange(API_URL, HttpMethod.GET, requestEntity, Imagen[].class);
	        Imagen[] imagenes = responseEntity.getBody();
    
	        return ResponseEntity.ok(Arrays.asList(imagenes));
	    }
	    @PostMapping("/imagenes/favoritos")
	    public ResponseEntity<String> marcarImagenFavorita(@RequestBody String imagenId) {
	        
	        return ResponseEntity.ok("Imagen marcada como favorita con éxito.");
	    }
	    @GetMapping("/imagenes/favoritos")
	    public ResponseEntity<List<Imagen>> obtenerImagenesFavoritas() {  
	        return ResponseEntity.ok(List.of());
	    }
	}

