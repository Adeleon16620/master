
public class GatosController {
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.*;

	import java.util.List;

	@RestController
	public class GatosController {

	    @GetMapping("/gatos")
	    public ResponseEntity<List<Gato>> obtenerTodosLosGatos() {
	       	        return ResponseEntity.ok(List.of());
	    }

	    @GetMapping("/gatos/{id}")
	    public ResponseEntity<Gato> obtenerGatoPorId(@PathVariable String id) {
	      	        return ResponseEntity.ok(new Gato());
	    }

	    @PostMapping("/gatos")
	    public ResponseEntity<String> crearGato(@RequestBody Gato gato) {
	       
	        return ResponseEntity.ok("Gato creado con éxito.");
	    }

	    @PutMapping("/gatos/{id}")
	    public ResponseEntity<String> actualizarGato(@PathVariable String id, @RequestBody Gato gato) {
	        
	        return ResponseEntity.ok("Gato actualizado con éxito.");
	    }

	    @DeleteMapping("/gatos/{id}")
	    public ResponseEntity<String> eliminarGato(@PathVariable String id) {
	       
	        return ResponseEntity.ok("Gato eliminado con éxito.");
	    }
}
