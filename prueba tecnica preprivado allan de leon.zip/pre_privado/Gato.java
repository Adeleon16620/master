
public class Gato {
	    private String nombre;
	    private String raza;
	    private int edad;
	    private String foto;

	   }
